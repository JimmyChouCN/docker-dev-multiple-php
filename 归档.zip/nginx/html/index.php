<?php
	phpinfo();